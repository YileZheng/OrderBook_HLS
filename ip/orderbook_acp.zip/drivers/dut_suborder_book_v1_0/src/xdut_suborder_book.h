// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XDUT_SUBORDER_BOOK_H
#define XDUT_SUBORDER_BOOK_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xdut_suborder_book_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XDut_suborder_book_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XDut_suborder_book;

typedef u32 word_type;

typedef struct {
    u32 word_0;
    u32 word_1;
    u32 word_2;
    u32 word_3;
    u32 word_4;
    u32 word_5;
} XDut_suborder_book_Order_message;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XDut_suborder_book_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XDut_suborder_book_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XDut_suborder_book_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XDut_suborder_book_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XDut_suborder_book_Initialize(XDut_suborder_book *InstancePtr, u16 DeviceId);
XDut_suborder_book_Config* XDut_suborder_book_LookupConfig(u16 DeviceId);
int XDut_suborder_book_CfgInitialize(XDut_suborder_book *InstancePtr, XDut_suborder_book_Config *ConfigPtr);
#else
int XDut_suborder_book_Initialize(XDut_suborder_book *InstancePtr, const char* InstanceName);
int XDut_suborder_book_Release(XDut_suborder_book *InstancePtr);
#endif

void XDut_suborder_book_Start(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_IsDone(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_IsIdle(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_IsReady(XDut_suborder_book *InstancePtr);
void XDut_suborder_book_EnableAutoRestart(XDut_suborder_book *InstancePtr);
void XDut_suborder_book_DisableAutoRestart(XDut_suborder_book *InstancePtr);

void XDut_suborder_book_Set_order_message(XDut_suborder_book *InstancePtr, XDut_suborder_book_Order_message Data);
XDut_suborder_book_Order_message XDut_suborder_book_Get_order_message(XDut_suborder_book *InstancePtr);
void XDut_suborder_book_Set_book(XDut_suborder_book *InstancePtr, u64 Data);
u64 XDut_suborder_book_Get_book(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_Get_book_head_b(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_Get_book_head_b_vld(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_Get_book_head_a(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_Get_book_head_a_vld(XDut_suborder_book *InstancePtr);

void XDut_suborder_book_InterruptGlobalEnable(XDut_suborder_book *InstancePtr);
void XDut_suborder_book_InterruptGlobalDisable(XDut_suborder_book *InstancePtr);
void XDut_suborder_book_InterruptEnable(XDut_suborder_book *InstancePtr, u32 Mask);
void XDut_suborder_book_InterruptDisable(XDut_suborder_book *InstancePtr, u32 Mask);
void XDut_suborder_book_InterruptClear(XDut_suborder_book *InstancePtr, u32 Mask);
u32 XDut_suborder_book_InterruptGetEnabled(XDut_suborder_book *InstancePtr);
u32 XDut_suborder_book_InterruptGetStatus(XDut_suborder_book *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
